package com.danny.controlventas;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class LocalBackupWorker extends Worker {
    public LocalBackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }
    @NonNull @Override public Result doWork() {
        try {
            File dir = new File(getApplicationContext().getFilesDir(), "backups");
            File latest = new File(dir, "latest.json");
            if (!latest.exists()) return Result.success();
            File dated = new File(dir, "daily_" + new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", java.util.Locale.US).format(new java.util.Date()) + ".json");
            try (FileInputStream in = new FileInputStream(latest); FileOutputStream out = new FileOutputStream(dated)) {
                byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); out.getFD().sync();
            }
            return Result.success();
        } catch (Exception e) { return Result.retry(); }
    }
}
