package com.danny.controlventas;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.InputStream;
import java.io.OutputStream;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 4101;
    private static final int REQ_IMPORT = 4102;
    private WebView web;
    private String pendingExportJson;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new BackupBridge(this), "DannyNative");
        BackupBridge.setActivity(this);
        web.loadUrl("file:///android_asset/index.html");
        PeriodicWorkRequest backup = new PeriodicWorkRequest.Builder(LocalBackupWorker.class, 24, TimeUnit.HOURS).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("danny_daily_local_backup", ExistingPeriodicWorkPolicy.UPDATE, backup);
    }
    private void exportJson(String json) {
        pendingExportJson = json;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "RESPALDO_CONTROL_VENTAS_DANNY_" + new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date()) + ".json");
        startActivityForResult(i, REQ_EXPORT);
    }
    private void importJson() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        startActivityForResult(i, REQ_IMPORT);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_EXPORT && pendingExportJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new java.io.IOException("No se pudo abrir el archivo");
                    out.write(pendingExportJson.getBytes(StandardCharsets.UTF_8)); out.flush();
                }
                pendingExportJson = null;
                web.evaluateJavascript("alert('Respaldo exportado correctamente. Guárdalo en una carpeta segura del teléfono.');", null);
            } else if (requestCode == REQ_IMPORT) {
                StringBuilder json = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri); java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line; while ((line = br.readLine()) != null) json.append(line);
                }
                String encoded = org.json.JSONObject.quote(json.toString());
                web.evaluateJavascript("importBackupFromNative(" + encoded + ")", null);
            }
        } catch (Exception e) {
            String msg = org.json.JSONObject.quote("No se pudo completar la operación: " + e.getMessage());
            web.evaluateJavascript("alert(" + msg + ")", null);
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    public static class BackupBridge {
        private static MainActivity activity;
        static void setActivity(MainActivity a) { activity = a; }
        private final Context context;
        BackupBridge(Context c) { context = c.getApplicationContext(); }
        @JavascriptInterface public void exportBackup(String json) { MainActivity a = activity; if (a != null) a.runOnUiThread(() -> a.exportJson(json)); }
        @JavascriptInterface public void importBackup() { MainActivity a = activity; if (a != null) a.runOnUiThread(a::importJson); }
        @JavascriptInterface public void saveSnapshot(String json) {
            try {
                File dir = new File(context.getFilesDir(), "backups"); if (!dir.exists()) dir.mkdirs();
                File tmp = new File(dir, "latest.json.tmp");
                try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(json.getBytes(StandardCharsets.UTF_8)); out.getFD().sync(); }
                File dest = new File(dir, "latest.json"); if (dest.exists()) dest.delete(); tmp.renameTo(dest);
                File dated = new File(dir, "backup_" + new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", java.util.Locale.US).format(new java.util.Date()) + ".json");
                try (FileOutputStream out = new FileOutputStream(dated)) { out.write(json.getBytes(StandardCharsets.UTF_8)); out.getFD().sync(); }
            } catch (Exception ignored) { }
        }
    }
}
